import { redirect } from "next/navigation";
import Link from "next/link";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export default async function AdminPage(){
 const session=await getSession();
 if(!session) redirect("/login");
 if(session.role!=="ADMIN") redirect("/dashboard");
 const [count,users]=await Promise.all([
  prisma.user.count(),
  prisma.user.findMany({take:100,orderBy:{createdAt:"desc"},select:{id:true,name:true,email:true,role:true,disabled:true,createdAt:true,demoAccount:{select:{balance:true}}}})
 ]);
 return <main className="simple-dashboard"><header className="dash-header"><div className="brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>ADMIN CONSOLE</small></div></div><Link className="outline-btn" href="/dashboard">Back to dashboard</Link></header><section className="dash-content"><span className="eyebrow">ADMINISTRATION</span><h1>User management</h1><p>{count} registered accounts · Showing latest {users.length}</p><div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Demo balance</th><th>Status</th><th>Joined</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>${Number(u.demoAccount?.balance??0).toFixed(2)}</td><td>{u.disabled?"Disabled":"Active"}</td><td>{u.createdAt.toLocaleDateString()}</td></tr>)}</tbody></table></div><div className="notice"><b>Admin bootstrap required</b><p>Create your first administrator by registering a normal account, then promote its role to ADMIN directly in the database using a trusted database console. Never expose an unauthenticated admin-creation endpoint.</p></div></section></main>;
}
