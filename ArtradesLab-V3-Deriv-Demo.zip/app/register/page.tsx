"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [error,setError]=useState(""); const [busy,setBusy]=useState(false); const router=useRouter();
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");
    const res=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,email,password})});
    const data=await res.json();setBusy(false);if(!res.ok){setError(data.error||"Could not register.");return;}router.push("/dashboard");
  }
  return <main className="auth-shell"><form className="auth-card" onSubmit={submit}><div className="brand auth-brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>TRADING TECHNOLOGY</small></div></div><h1>Create your account</h1><p>Start with a virtual demo balance and live market information.</p>
    <label>Full name</label><input required minLength={2} value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/>
    <label>Email address</label><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/>
    <label>Password</label><input required minLength={10} type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 10 characters"/>
    {error&&<div className="form-error">{error}</div>}<button className="primary-btn auth-submit" disabled={busy}>{busy?"Creating account…":"Create account"}</button>
    <small className="auth-note">Registration creates a demo account with virtual funds only. It does not open a broker account.</small><div className="auth-switch">Already registered? <Link href="/login">Sign in</Link></div>
  </form></main>;
}
