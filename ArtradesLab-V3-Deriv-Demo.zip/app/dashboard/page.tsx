import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  const user = await prisma.user.findUnique({
    where: { id: session.sub },
    select: { name: true, email: true, role: true, demoAccount: true }
  });
  if (!user) redirect("/login");
  return <main className="simple-dashboard">
    <header className="dash-header">
      <div className="brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>TRADING TECHNOLOGY</small></div></div>
      <div className="dash-links"><Link className="outline-btn" href="/deriv-demo">Connect Deriv demo</Link><Link className="outline-btn" href="/">Trading terminal</Link><form action="/api/auth/logout" method="post"><button className="outline-btn" type="submit">Sign out</button></form></div>
    </header>
    <section className="dash-content"><span className="eyebrow">ACCOUNT OVERVIEW</span><h1>Welcome, {user.name}</h1><p>{user.email}</p>
      <div className="dash-cards"><div className="stat"><span>ArtradesLab demo balance</span><b>${Number(user.demoAccount?.balance ?? 0).toFixed(2)}</b><small>Virtual funds · USD</small></div><div className="stat"><span>Account type</span><b>Demo workspace</b><small>Live market data, virtual tickets</small></div><div className="stat"><span>Access level</span><b>{user.role}</b><small>Account permissions</small></div></div>
      <div className="notice"><b>ArtradesLab demo balance is separate from Deriv.</b><p>Connect a Deriv demo account to trade on Deriv's demo environment. Your ArtradesLab virtual ledger is not a broker account and cannot be deposited or withdrawn.</p></div>
      <Link className="primary-btn" href="/deriv-demo">Connect and trade with Deriv demo</Link>
      {user.role==="ADMIN"&&<div style={{marginTop:18}}><Link className="outline-btn" href="/admin">Open admin console</Link></div>}
    </section>
  </main>;
}
