import { redirect } from "next/navigation";
import Link from "next/link";
import { getSession } from "@/lib/session";
import DerivDemoClient from "./terminal";
export default async function DerivDemoPage(){
 const session=await getSession(); if(!session) redirect("/login");
 return <main className="simple-dashboard"><header className="dash-header"><div className="brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>DERIV DEMO TERMINAL</small></div></div><Link className="outline-btn" href="/dashboard">Back to dashboard</Link></header><section className="dash-content"><span className="eyebrow">BROKER DEMO CONNECTION</span><h1>Deriv demo trading</h1><p>Connect your own Deriv demo account to request quotes and place demo contracts.</p><DerivDemoClient/></section></main>;
}
