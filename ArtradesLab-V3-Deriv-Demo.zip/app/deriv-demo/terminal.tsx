"use client";
import { useEffect, useRef, useState } from "react";

type Msg = Record<string,any>;
export default function DerivDemoClient(){
 const [token,setToken]=useState(""); const [accountId,setAccountId]=useState("");
 const [connected,setConnected]=useState(false); const [status,setStatus]=useState("Not connected");
 const [symbol,setSymbol]=useState("1HZ100V"); const [stake,setStake]=useState("1");
 const [duration,setDuration]=useState("5"); const [unit,setUnit]=useState("m");
 const [direction,setDirection]=useState<"CALL"|"PUT">("CALL");
 const [quote,setQuote]=useState<Msg|null>(null); const [contract,setContract]=useState<Msg|null>(null);
 const [balance,setBalance]=useState<string>("—"); const [error,setError]=useState("");
 const ws=useRef<WebSocket|null>(null); const proposalId=useRef<string|null>(null); const req=useRef(10);
 const send=(payload:Msg)=>{if(ws.current?.readyState===WebSocket.OPEN)ws.current.send(JSON.stringify({...payload,req_id:++req.current}));};
 async function connectAccount(e:React.FormEvent){
  e.preventDefault();setError("");setStatus("Validating Deriv demo account…");
  const res=await fetch("/api/deriv/connect",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token,accountId,accountType:"demo"})});
  const data=await res.json(); if(!res.ok){setStatus("Not connected");setError(data.error||"Connection failed");return;}
  setToken(""); await openSession();
 }
 async function openSession(){
  setError("");setStatus("Requesting secure demo session…");
  const res=await fetch("/api/deriv/session",{method:"POST"});
  const data=await res.json();if(!res.ok){setStatus("Not connected");setError(data.error||"Could not start session");return;}
  const socket=new WebSocket(data.url);ws.current=socket;
  socket.onopen=()=>{setConnected(true);setStatus("Connected to Deriv demo");socket.send(JSON.stringify({authorize:1,req_id:++req.current}));socket.send(JSON.stringify({balance:1,subscribe:1,req_id:++req.current}));socket.send(JSON.stringify({active_symbols:"brief",product_type:"basic",req_id:++req.current}));};
  socket.onmessage=(event)=>{
   const msg=JSON.parse(event.data);
   if(msg.error){setError(msg.error.message||"Deriv request failed");return;}
   if(msg.msg_type==="authorize"){setStatus("Authenticated demo account");}
   if(msg.msg_type==="balance"&&msg.balance)setBalance(`${msg.balance.currency} ${Number(msg.balance.balance).toFixed(2)}`);
   if(msg.msg_type==="proposal"&&msg.proposal){proposalId.current=msg.proposal.id;setQuote(msg.proposal);}
   if(msg.msg_type==="buy"&&msg.buy){setContract(msg.buy);setStatus(`Demo contract purchased · ${msg.buy.contract_id}`);send({proposal_open_contract:1,contract_id:msg.buy.contract_id,subscribe:1});}
   if(msg.msg_type==="proposal_open_contract"&&msg.proposal_open_contract){setContract(msg.proposal_open_contract);}
  };
  socket.onerror=()=>{setStatus("WebSocket connection error");setError("Deriv WebSocket connection failed.");};
  socket.onclose=()=>{setConnected(false);setStatus("Disconnected");};
 }
 function requestQuote(){
  setError("");setQuote(null);proposalId.current=null;
  const amount=Number(stake),dur=Number(duration);
  if(!Number.isFinite(amount)||amount<=0||!Number.isFinite(dur)||dur<=0){setError("Enter a valid stake and duration.");return;}
  send({proposal:1,amount,basis:"stake",contract_type:direction,currency:"USD",duration:dur,duration_unit:unit,underlying_symbol:symbol});
 }
 function buy(){
  if(!quote?.id){setError("Request a valid quote first.");return;}
  send({buy:quote.id,price:Number(quote.ask_price)});
  setQuote(null);proposalId.current=null;
 }
 function disconnect(){ws.current?.close();ws.current=null;setConnected(false);setStatus("Disconnected");setQuote(null);}
 useEffect(()=>()=>{ws.current?.close();},[]);
 return <div className="deriv-box">
  <div className="notice"><b>Demo-only broker connection</b><p>This page only accepts a Deriv demo Options account. Real accounts are rejected by the server. Your Deriv token is encrypted at rest and never returned to the browser after saving. For production, use Deriv OAuth rather than asking users to paste a token.</p></div>
  {!connected&&<form className="deriv-connect" onSubmit={connectAccount}>
   <h3>Connect your Deriv demo account</h3><label>Deriv demo account ID</label><input required value={accountId} onChange={e=>setAccountId(e.target.value)} placeholder="Your demo account ID"/>
   <label>Deriv Personal Access Token</label><input required type="password" value={token} onChange={e=>setToken(e.target.value)} placeholder="Paste a token with trade scope"/>
   <small>Create a restricted token in your Deriv account with the required trading scope. Never share it with anyone. Deriv OAuth is the recommended production sign-in method.</small>
   <button className="primary-btn auth-submit">Validate and connect</button>
  </form>}
  <div className="deriv-status"><span className={connected?"live-dot":"status-dot"}/>{status}{connected&&<button className="outline-btn" onClick={disconnect}>Disconnect</button>}</div>
  {connected&&<div className="deriv-trade">
   <div className="stat"><span>Deriv demo balance</span><b>{balance}</b><small>Reported by Deriv</small></div>
   <label>Market symbol</label><select value={symbol} onChange={e=>setSymbol(e.target.value)}><option value="1HZ10V">Volatility 10 (1s)</option><option value="1HZ25V">Volatility 25 (1s)</option><option value="1HZ50V">Volatility 50 (1s)</option><option value="1HZ75V">Volatility 75 (1s)</option><option value="1HZ100V">Volatility 100 (1s)</option><option value="R_10">Volatility 10</option><option value="R_25">Volatility 25</option><option value="R_50">Volatility 50</option><option value="R_75">Volatility 75</option><option value="R_100">Volatility 100</option></select>
   <div className="deriv-fields"><div><label>Stake (USD)</label><input value={stake} onChange={e=>setStake(e.target.value)} type="number" min="0.35" step="0.01"/></div><div><label>Duration</label><input value={duration} onChange={e=>setDuration(e.target.value)} type="number" min="1"/></div><div><label>Unit</label><select value={unit} onChange={e=>setUnit(e.target.value)}><option value="t">Ticks</option><option value="s">Seconds</option><option value="m">Minutes</option></select></div></div>
   <label>Contract direction</label><div className="direction"><button type="button" className={direction==="CALL"?"up active-dir":"up"} onClick={()=>setDirection("CALL")}>↗ Rise</button><button type="button" className={direction==="PUT"?"down active-dir":"down"} onClick={()=>setDirection("PUT")}>↘ Fall</button></div>
   <button className="primary-btn auth-submit" onClick={requestQuote}>Get contract quote</button>
   {quote&&<div className="quote-card"><b>Deriv proposal</b><p>Ask price: {quote.currency} {Number(quote.ask_price).toFixed(2)}</p><p>Potential payout: {quote.currency} {Number(quote.payout).toFixed(2)}</p><button className="execute" onClick={buy}>Buy demo contract</button></div>}
   {contract&&<div className="quote-card"><b>Latest contract update</b><p>Contract ID: {contract.contract_id}</p><p>Status: {contract.status||contract.contract_status||"Submitted"}</p><p>Buy price: {contract.buy_price??"—"} · Profit: {contract.profit??"—"}</p></div>}
  </div>}
  {error&&<div className="form-error">{error}</div>}
 </div>;
}
