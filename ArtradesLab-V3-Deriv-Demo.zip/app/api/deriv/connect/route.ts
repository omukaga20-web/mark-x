import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { encryptSecret } from "@/lib/crypto";

const schema = z.object({
  token: z.string().min(20).max(5000),
  accountId: z.string().min(3).max(40),
  accountType: z.literal("demo")
});

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Sign in to ArtradesLab first." }, { status: 401 });
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Provide a valid Deriv token and demo account ID." }, { status: 400 });

  const appId = process.env.DERIV_APP_ID;
  if (!appId) return NextResponse.json({ error: "Deriv App ID is not configured by the platform administrator." }, { status: 503 });

  // Validate the credential and ensure the chosen account is actually a demo Options account.
  try {
    const response = await fetch("https://api.derivws.com/trading/v1/options/accounts", {
      headers: { Authorization: `Bearer ${parsed.data.token}`, "Deriv-App-ID": appId },
      cache: "no-store"
    });
    const payload = await response.json();
    if (!response.ok) return NextResponse.json({ error: "Deriv rejected this token. Check its permissions and App ID." }, { status: 400 });

    const accounts = payload?.data ?? payload?.accounts ?? [];
    const match = Array.isArray(accounts) ? accounts.find((a:any) =>
      String(a.account_id ?? a.accountId ?? a.id) === parsed.data.accountId &&
      String(a.account_type ?? a.accountType ?? "").toLowerCase() === "demo"
    ) : null;
    if (!match) return NextResponse.json({ error: "That account was not returned as a demo Options account for this token." }, { status: 400 });

    const encrypted = encryptSecret(parsed.data.token);
    await prisma.derivCredential.upsert({
      where: { userId: session.sub },
      create: { userId: session.sub, accountId: parsed.data.accountId, accountType: "demo", ...encrypted },
      update: { accountId: parsed.data.accountId, accountType: "demo", ...encrypted }
    });
    return NextResponse.json({ ok: true, accountId: parsed.data.accountId });
  } catch {
    return NextResponse.json({ error: "Could not validate or securely store the Deriv connection." }, { status: 500 });
  }
}
