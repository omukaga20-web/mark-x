import { NextResponse } from "next/server";
import { getSession } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { decryptSecret } from "@/lib/crypto";

export async function POST() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const credential = await prisma.derivCredential.findUnique({ where: { userId: session.sub } });
  if (!credential || credential.accountType !== "demo") return NextResponse.json({ error: "Connect a Deriv demo account first." }, { status: 400 });

  try {
    const token = decryptSecret(credential);
    const headers: Record<string,string> = { Authorization: `Bearer ${token}` };
    if (process.env.DERIV_AUTH_TYPE !== "oauth") headers["Deriv-App-ID"] = process.env.DERIV_APP_ID || "";
    const response = await fetch(`https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(credential.accountId)}/otp`, {
      method: "POST", headers, cache: "no-store"
    });
    const payload = await response.json();
    const url = payload?.data?.url;
    if (!response.ok || typeof url !== "string" || !url.startsWith("wss://api.derivws.com/trading/v1/options/ws/demo?")) {
      return NextResponse.json({ error: "Deriv could not issue a demo WebSocket session. Reconnect your account." }, { status: 502 });
    }
    // OTP URL is short-lived and returned only to the authenticated owner.
    return NextResponse.json({ url, accountId: credential.accountId }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "Could not create a Deriv demo session." }, { status: 500 });
  }
}
