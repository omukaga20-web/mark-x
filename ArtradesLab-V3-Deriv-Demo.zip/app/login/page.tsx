"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
export default function LoginPage(){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [error,setError]=useState("");const [busy,setBusy]=useState(false);const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");const res=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});const data=await res.json();setBusy(false);if(!res.ok){setError(data.error||"Could not sign in.");return;}router.push("/dashboard");}
 return <main className="auth-shell"><form className="auth-card" onSubmit={submit}><div className="brand auth-brand"><div className="brand-mark">A</div><div><b>Artrades<span>Lab</span></b><small>TRADING TECHNOLOGY</small></div></div><h1>Welcome back</h1><p>Sign in to your ArtradesLab workspace.</p><label>Email address</label><input required type="email" value={email} onChange={e=>setEmail(e.target.value)}/><label>Password</label><input required type="password" value={password} onChange={e=>setPassword(e.target.value)}/>{error&&<div className="form-error">{error}</div>}<button className="primary-btn auth-submit" disabled={busy}>{busy?"Signing in…":"Sign in"}</button><div className="auth-switch">New to ArtradesLab? <Link href="/register">Create an account</Link></div></form></main>;
}
