import crypto from "node:crypto";

function key() {
  const value = process.env.TOKEN_ENCRYPTION_KEY;
  if (!value || !/^[a-fA-F0-9]{64}$/.test(value)) {
    throw new Error("TOKEN_ENCRYPTION_KEY must be a 64-character hex key.");
  }
  return Buffer.from(value, "hex");
}
export function encryptSecret(plain: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key(), iv);
  const encrypted = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  return { encryptedToken: encrypted.toString("base64"), iv: iv.toString("base64"), authTag: cipher.getAuthTag().toString("base64") };
}
export function decryptSecret(data: { encryptedToken: string; iv: string; authTag: string }) {
  const decipher = crypto.createDecipheriv("aes-256-gcm", key(), Buffer.from(data.iv, "base64"));
  decipher.setAuthTag(Buffer.from(data.authTag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(data.encryptedToken, "base64")), decipher.final()]).toString("utf8");
}
