# ArtradesLab V3

Full-stack Next.js + PostgreSQL/Prisma starter with user registration, login, per-user demo balance, admin views, and an authenticated Deriv **demo-account** trading connection.

## Requirements
- Node.js 20+
- PostgreSQL
- A Deriv developer App ID
- A Deriv demo Options account and a restricted Personal Access Token with `trade` scope (OAuth is recommended for production)

## Setup
1. `npm install`
2. Copy `.env.example` to `.env.local`.
3. Set `DATABASE_URL`, a strong `SESSION_SECRET`, `TOKEN_ENCRYPTION_KEY` (64 hex characters), and your Deriv App ID.
4. `npx prisma generate`
5. `npx prisma db push` (or `npx prisma migrate dev --name init`)
6. `npm run dev`
7. Visit `/register`, create an ArtradesLab user, then visit `/dashboard` → Connect Deriv demo.

Generate an encryption key with:
`openssl rand -hex 32`

## V3 features
- Encrypted-at-rest Deriv token storage using AES-256-GCM.
- Server-side validation that the linked Options account is a demo account.
- Server-side OTP creation; short-lived OTP WebSocket URL returned only to the signed-in account owner.
- Browser connection to Deriv's authenticated demo WebSocket.
- Demo balance subscription, contract proposal, demo purchase, and contract status subscription.
- Real account WebSocket endpoint is rejected by server validation.
- ArtradesLab internal demo ledger remains separate from Deriv demo account.

## Deriv API workflow
The implementation follows the current Deriv API pattern: REST bearer-token authentication to request an OTP, then connect to the returned demo WebSocket URL. See:
- https://developers.deriv.com/docs/intro/api-overview/
- https://developers.deriv.com/docs/intro/authentication/
- https://developers.deriv.com/docs/options/
- https://developers.deriv.com/docs/trading/proposal/
- https://developers.deriv.com/docs/trading/buy/
- https://developers.deriv.com/docs/workflows/

The Deriv API may change. Confirm current app setup, token scopes, symbol availability, minimum stakes, and contract parameters in Deriv's official documentation. The sample market list is illustrative and the provider validates every proposal.

## Security and launch checklist
- This starter accepts a Deriv PAT as a temporary integration method. For public production, implement Deriv OAuth Authorization Code + PKCE, secure token lifecycle, token revocation, rate limiting, CSRF protections, email verification, password reset, monitoring, and a professional security review.
- `TOKEN_ENCRYPTION_KEY` must be a strong secret and must never be committed to source control. Rotate it only with a planned credential re-encryption migration.
- Do not log tokens, OTP URLs, or authorization headers.
- Use HTTPS in production.
- The Deriv demo token must be scoped appropriately and must belong to the selected demo account.
- Real-money account linking, real trading, deposits, withdrawals, custody, and user fund handling are intentionally not implemented. They require an approved broker/partner arrangement and jurisdiction-specific regulatory, KYC/AML, safeguarding, and legal review.
- The sample UI supports basic Rise/Fall proposals and buy requests. It is not a complete production trading terminal and has not been verified against your own Deriv app/account in this environment.
